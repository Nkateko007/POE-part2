package prog5121poe;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    @Test
    public void testMessageObjectCreated() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello World",
                1,
                "Sent"
        );

        assertNotNull(msg);
    }

    @Test
    public void testSenderStored() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello",
                1,
                "Sent"
        );

        assertEquals(
                "user_1",
                msg.getSender()
        );
    }

    @Test
    public void testRecipientStored() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello",
                1,
                "Sent"
        );

        assertEquals(
                "+27831234567",
                msg.getRecipient()
        );
    }

    @Test
    public void testMessageTextStored() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello",
                1,
                "Sent"
        );

        assertEquals(
                "Hello",
                msg.getMessageText()
        );
    }

    @Test
    public void testStatusStored() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello",
                1,
                "Sent"
        );

        assertEquals(
                "Sent",
                msg.getStatus()
        );
    }

    @Test
    public void testMessageIDGenerated() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello",
                1,
                "Sent"
        );

        assertNotNull(
                msg.getMessageID()
        );
    }

    @Test
    public void testMessageHashGenerated() {

        Message msg = new Message(
                "user_1",
                "+27831234567",
                "Hello",
                1,
                "Sent"
        );

        assertNotNull(
                msg.getMessageHash()
        );
    }
}