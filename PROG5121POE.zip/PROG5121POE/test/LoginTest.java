package prog5121poe;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    Login login = new Login();

    @Test
    public void testValidUsername() {

        boolean result = login.checkUserName("kyl_1");

        assertTrue(result);
    }

    @Test
    public void testInvalidUsername() {

        boolean result = login.checkUserName("kyle!!!!");

        assertFalse(result);
    }

    @Test
    public void testValidPassword() {

        boolean result = login.checkPasswordComplexity("Password@1");

        assertTrue(result);
    }

    @Test
    public void testInvalidPassword() {

        boolean result = login.checkPasswordComplexity("password");

        assertFalse(result);
    }

    @Test
    public void testValidCellNumber() {

        boolean result = login.checkCellPhoneNumber("+27831234567");

        assertTrue(result);
    }

    @Test
    public void testInvalidCellNumber() {

        boolean result = login.checkCellPhoneNumber("0831234567");

        assertFalse(result);
    }

    @Test
    public void testSuccessfulLogin() {

        boolean result = login.loginUser(
                "kyl_1",
                "Password@1",
                "kyl_1",
                "Password@1"
        );

        assertTrue(result);
    }

    @Test
    public void testFailedLogin() {

        boolean result = login.loginUser(
                "kyl_1",
                "Password@1",
                "john_1",
                "abc123"
        );

        assertFalse(result);
    }

    @Test
    public void testReturnLoginStatusSuccess() {

        String result = login.returnLoginStatus(
                true,
                "Kyle",
                "Smith"
        );

        assertEquals(
                "Welcome Kyle Smith. It is great to see you again.",
                result
        );
    }

    @Test
    public void testReturnLoginStatusFail() {

        String result = login.returnLoginStatus(
                false,
                "Kyle",
                "Smith"
        );

        assertEquals(
                "Username or password incorrect. Please try again.",
                result
        );
    }
}