
package prog5121poe;


import java.util.Random;

/**
 * ---------------------------------------------------------
 * Message Class
 * ---------------------------------------------------------
 * This class represents a single QuickChat message.
 *
 * Responsibilities:
 * - Store message information
 * - Generate a unique 10-digit Message ID
 * - Validate Message ID
 * - Validate recipient cellphone number
 * - Create a message hash
 *
 * NOTE:
 * This class DOES NOT:
 * - Store arrays of messages
 * - Search messages
 * - Delete messages
 * - Generate reports
 *
 * Those responsibilities belong to MessageManager.java
 * ---------------------------------------------------------
 */
public class Message {

    /*-------------------------------------------------------
      Instance Variables
    -------------------------------------------------------*/

    // Unique message ID
    private String messageID;

    // Generated message hash
    private String messageHash;

    // Person sending the message
    private String sender;

    // Recipient cellphone number
    private String recipient;

    // Actual message text
    private String messageText;

    // Status:
    // Sent
    // Stored
    // Disregarded
    private String status;

    // Message number used in hash generation
    private int messageNumber;

    /*-------------------------------------------------------
      Constructor
    -------------------------------------------------------*/

    /**
     * Creates a new Message object.
     *
     * @param sender Name of sender
     * @param recipient Recipient cellphone number
     * @param messageText Message content
     * @param messageNumber Sequential message number
     * @param status Current message status
     */
    public Message(String sender,
                   String recipient,
                   String messageText,
                   int messageNumber,
                   String status) {

        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.status = "created";

        // Generate ID automatically
        this.messageID = generateMessageID();

        // Generate Hash automatically
        this.messageHash = createMessageHash();
    }

    /*-------------------------------------------------------
      Generate Random 10-Digit Message ID
    -------------------------------------------------------*/

    /**
     * Generates a random 10-digit numeric ID.
     *
     * @return 10-digit String
     */
    public String generateMessageID() {

        Random random = new Random();

        long number =
                1000000000L
                        + (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }

    /*-------------------------------------------------------
      Validate Message ID
    -------------------------------------------------------*/

    /**
     * Checks whether the Message ID is valid.
     *
     * Requirement:
     * Maximum 10 characters.
     *
     * @return true if valid
     */
    public boolean checkMessageID() {

        if (messageID == null) {
            return false;
        }

        return messageID.length() <= 10;
    }

    /*-------------------------------------------------------
      Validate Recipient Cell Number
    -------------------------------------------------------*/

    /**
     * Validates South African cellphone number.
     *
     * Example:
     * +27831234567
     *
     * @return true if valid
     */
    public boolean checkRecipientCell() {

        if (recipient == null) {
            return false;
        }

        return recipient.matches("^\\+27\\d{9}$");
    }

    /*-------------------------------------------------------
      Create Message Hash
    -------------------------------------------------------*/

    /**
     * Creates message hash using:
     *
     * First 2 digits of Message ID
     * :
     * Message Number
     * :
     * First Word + Last Word
     *
     * Example:
     * 12:1:HELLOWORLD
     *
     * @return Message Hash
     */
    public String createMessageHash() {

        if (messageText == null || messageText.trim().equals("")) {
            return "";
        }

        String[] words = messageText.trim().split("\\s+");

String firstWord = "";
String lastWord = "";

if (words.length > 0) {
    firstWord = words[0];
    lastWord = words[words.length - 1];
}

return (messageID.substring(0, 2)
        + ":"
        + messageNumber
        + ":"
        + firstWord
        + lastWord).toUpperCase();
    }

    /*-------------------------------------------------------
      Getters
    -------------------------------------------------------*/

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getStatus() {
        return status;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    /*-------------------------------------------------------
      Setters
    -------------------------------------------------------*/

    public void setStatus(String status) {
        this.status = status;
    }

    /*-------------------------------------------------------
      Display Message
    -------------------------------------------------------*/

    /**
     * Returns formatted message details.
     *
     * @return formatted String
     */
    @Override
    public String toString() {

        return
                "Message ID    : " + messageID
                        + "\nMessage Hash  : " + messageHash
                        + "\nSender        : " + sender
                        + "\nRecipient     : " + recipient
                        + "\nStatus        : " + status
                        + "\nMessage       : " + messageText;
    }
    public void setMessageHash(String messageHash) {
    this.messageHash = messageHash;
}
    public void setMessageID(String messageID) {
    this.messageID = messageID;
}

}
