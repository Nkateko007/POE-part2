
package prog5121poe;

/**
 * Login class
 *
 * Handles:
 * - Username validation
 * - Password validation
 * - South African cellphon validation
 * - User login verification
 */
public class Login {

    /**
     * Username requirements:
     * - Must contain an underscore (_)
     * - Must not exceed 5 characters
     */
    public boolean checkUserName(String username) {

        if (username == null) {
            return false;
        }

        return username.contains("_")
                && username.length() <= 5;
    }

    /**
     * Password requirements:
     * - Minimum 8 characters
     * - One uppercase letter
     * - One lowercase letter
     * - One digit
     * - One special character
     */
    public boolean checkPasswordComplexity(String password) {

        if (password == null) {
            return false;
        }

        return password.matches(
                "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$"
        );
    }

    /**
     * Validates South African cellphone numbers.
     *
     * Example:
     * +27831234567
     */
    public boolean checkCellPhoneNumber(String phoneNumber) {

        if (phoneNumber == null) {
            return false;
        }

        return phoneNumber.matches("^\\+27\\d{9}$");
    }

    /**
     * Checks login credentials.
     */
    public boolean loginUser(
            String registeredUsername,
            String registeredPassword,
            String enteredUsername,
            String enteredPassword) {

        return registeredUsername.equals(enteredUsername)
                && registeredPassword.equals(enteredPassword);
    }

    /**
     * Returns login status message.
     */
    public String returnLoginStatus(
            boolean success,
            String firstName,
            String lastName) {

        if (success) {

            return "Welcome "
                    + firstName
                    + " "
                    + lastName
                    + ". It is great to see you again.";
        }

        return "Username or password incorrect. Please try again.";
    }
}