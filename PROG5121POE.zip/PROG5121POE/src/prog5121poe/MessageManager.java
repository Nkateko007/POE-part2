
package prog5121poe;


import java.util.ArrayList;

/**
 * ==========================================================
 * MessageManager Class
 * ==========================================================
 *
 * This class manages all messages in the QuickChat system.
 *
 * Responsibilities:
 *
 * - Store sent messages
 * - Store disregarded messages
 * - Store stored messages
 * - Store message hashes
 * - Store message IDs
 * - Count total messages
 *
 *
 * ==========================================================
 */
public class MessageManager {

    /*
     * ======================================================
     * ArrayLists 
     * ======================================================
     */

    // Stores messages that have been sent
    private ArrayList<Message> sentMessages;

    // Stores messages that have been disregarded
    private ArrayList<Message> disregardedMessages;

    // Stores messages saved for later use
    private ArrayList<Message> storedMessages;

    // Stores all generated message hashes
    private ArrayList<String> messageHashes;

    // Stores all generated message IDs
    private ArrayList<String> messageIDs;

    /*
     * Total number of messages sent.
     */
    private int totalMessages;

    /**
     * ======================================================
     * Constructor
     * ======================================================
     *
     * Initializes all ArrayLists.
     */
    public MessageManager() {

        sentMessages = new ArrayList<Message>();

        disregardedMessages = new ArrayList<Message>();

        storedMessages = new ArrayList<Message>();

        messageHashes = new ArrayList<String>();

        messageIDs = new ArrayList<String>();

        totalMessages = 0;
    }

    /**
     * ======================================================
     * Send Message
     * ======================================================
     *
     * Adds a message to:
     *
     * - Sent Messages
     * - Message Hashes
     * - Message IDs
     *
     * Increments total messages.
     *
     * @param message Message object
     */
    public void sendMessage(Message message) {

        if (message == null) {
            return;
        }

        // Update status
        message.setStatus("Sent");

        // Store message
        sentMessages.add(message);

        // Store hash
        if (!messageHashes.contains(message.getMessageHash())) {
    messageHashes.add(message.getMessageHash());
}

        // Store ID
       if (!messageIDs.contains(message.getMessageID())) {
    messageIDs.add(message.getMessageID());
}

        // Increase total
        totalMessages++;
    }

    /**
     * ======================================================
     * Store Message
     * ======================================================
     *
     * Adds a message to:
     *
     * - Stored Messages
     * - Message Hashes
     * - Message IDs
     *
     * NOTE:
     * JSON saving will be handled later by JsonManager.
     *
     * @param message Message object
     */
    public void storeMessage(Message message) {

        if (message == null) {
            return;
        }

        storedMessages.add(message);

if (!messageHashes.contains(message.getMessageHash())) {
    messageHashes.add(message.getMessageHash());
}

if (!messageIDs.contains(message.getMessageID())) {
    messageIDs.add(message.getMessageID());
}

/* Save to JSON file */
JsonManager.saveMessage(message);
    }

    /**
     * ======================================================
     * Disregard Message
     * ======================================================
     *
     * Adds message to disregarded list.
     *
     * @param message Message object
     */
    public void disregardMessage(Message message) {

        if (message == null) {
            return;
        }

        message.setStatus("Disregarded");

        disregardedMessages.add(message);
    }

    /**
     * ======================================================
     * Return Total Messages Sent
     * ======================================================
     *
     * @return total sent messages
     */
    public int getTotalMessages() {

        return totalMessages;
    }

    /**
     * ======================================================
     * Return Sent Messages
     * ======================================================
     *
     * @return sentMessages ArrayList
     */
    public ArrayList<Message> getSentMessages() {

        return sentMessages;
    }

    /**
     * ======================================================
     * Return Stored Messages
     * ======================================================
     *
     * @return storedMessages ArrayList
     */
    public ArrayList<Message> getStoredMessages() {

        return storedMessages;
    }

    /**
     * ======================================================
     * Return Disregarded Messages
     * ======================================================
     *
     * @return disregardedMessages ArrayList
     */
    public ArrayList<Message> getDisregardedMessages() {

        return disregardedMessages;
    }

    /**
     * ======================================================
     * Return Message Hashes
     * ======================================================
     *
     * @return messageHashes ArrayList
     */
    public ArrayList<String> getMessageHashes() {

        return messageHashes;
    }

    /**
     * ======================================================
     * Return Message IDs
     * ======================================================
     *
     * @return messageIDs ArrayList
     */
    public ArrayList<String> getMessageIDs() {

        return messageIDs;
    }
    
    /*
 * Display sender and recipient for all stored messages.
 */
public void displaySenderAndRecipient() {

    if (storedMessages.isEmpty()) {
        System.out.println("No stored messages found.");
        return;
    }

    for (int i = 0; i < storedMessages.size(); i++) {

        Message msg = storedMessages.get(i);

        System.out.println("--------------------------------");
        System.out.println("Sender    : " + msg.getSender());
        System.out.println("Recipient : " + msg.getRecipient());
    }
}

/*
 * Returns the longest stored message.
 */
public Message getLongestStoredMessage() {

    if (storedMessages.isEmpty()) {
        return null;
    }

    Message longestMessage = storedMessages.get(0);

    for (int i = 1; i < storedMessages.size(); i++) {

        Message current = storedMessages.get(i);

        if (current.getMessageText().length()
                > longestMessage.getMessageText().length()) {

            longestMessage = current;
        }
    }

    return longestMessage;
}

/*
 * Displays the longest stored message.
 */
public void displayLongestStoredMessage() {

    Message longest = getLongestStoredMessage();

    if (longest == null) {

        System.out.println("No stored messages available.");
        return;
    }

    System.out.println("========== LONGEST MESSAGE ==========");
    System.out.println("Sender      : " + longest.getSender());
    System.out.println("Recipient   : " + longest.getRecipient());
    System.out.println("Message ID  : " + longest.getMessageID());
    System.out.println("Message Hash: " + longest.getMessageHash());
    System.out.println("Message     : " + longest.getMessageText());
    
}
/*
 * Search for a message using its Message ID.
 */
public Message searchByMessageID(String messageID) {

    if (messageID == null) {
        return null;
    }

    for (int i = 0; i < storedMessages.size(); i++) {

        Message msg = storedMessages.get(i);

        if (msg.getMessageID().equals(messageID)) {
            return msg;
        }
    }

    return null;
}

/*
 * Display the details of a message found by Message ID.
 */
public void displayMessageByID(String messageID) {

    Message msg = searchByMessageID(messageID);

    if (msg == null) {

        System.out.println("Message not found.");
        return;
    }

    System.out.println("========== MESSAGE FOUND ==========");
    System.out.println("Message ID : " + msg.getMessageID());
    System.out.println("Sender     : " + msg.getSender());
    System.out.println("Recipient  : " + msg.getRecipient());
    System.out.println("Message    : " + msg.getMessageText());
}
/*
 * Display all messages sent to a specific recipient.
 */
public void searchByRecipient(String recipient) {

    boolean found = false;

    for (int i = 0; i < storedMessages.size(); i++) {

        Message msg = storedMessages.get(i);

        if (msg.getRecipient().equals(recipient)) {

            found = true;

            System.out.println("--------------------------------");
            System.out.println("Sender    : " + msg.getSender());
            System.out.println("Recipient : " + msg.getRecipient());
            System.out.println("Message   : " + msg.getMessageText());
        }
    }

    if (!found) {
        System.out.println("No messages found for this recipient.");
    }
}
/*
 * Returns all messages for a recipient.
 */
public ArrayList<Message> getMessagesForRecipient(String recipient) {

    ArrayList<Message> results = new ArrayList<Message>();

    for (int i = 0; i < storedMessages.size(); i++) {

        Message msg = storedMessages.get(i);

        if (msg.getRecipient().equals(recipient)) {
            results.add(msg);
        }
    }

    return results;
    
}
/*
 * Deletes a stored message using its message hash.
 */
public boolean deleteByHash(String hash) {

    if (hash == null) {
        return false;
    }

    for (int i = 0; i < storedMessages.size(); i++) {

        Message msg = storedMessages.get(i);

        if (msg.getMessageHash().equalsIgnoreCase(hash)) {

            storedMessages.remove(i);
            messageHashes.remove(hash);

            return true;
        }
    }

    return false;
}
/*
 * Displays all stored messages.
 */
public void displayAllStoredMessages() {

    if (storedMessages.isEmpty()) {

        System.out.println("No stored messages available.");
        return;
    }

    System.out.println("========== STORED MESSAGES ==========");

    for (int i = 0; i < storedMessages.size(); i++) {

        System.out.println(storedMessages.get(i));
        System.out.println("-----------------------------------");
    }
}
/*
 * Displays all sent messages.
 */
public void displayAllSentMessages() {

    if (sentMessages.isEmpty()) {

        System.out.println("No sent messages available.");
        return;
    }

    System.out.println("========== SENT MESSAGES ==========");

    for (int i = 0; i < sentMessages.size(); i++) {

        System.out.println(sentMessages.get(i));
        System.out.println("-----------------------------------");
    }
}
/*
 * Displays a complete report of all sent messages.
 */
public void generateReport() {

    if (sentMessages.isEmpty()) {

        System.out.println("No messages to report.");
        return;
    }

    System.out.println();
    System.out.println("========== MESSAGE REPORT ==========");

    for (int i = 0; i < sentMessages.size(); i++) {

        Message msg = sentMessages.get(i);

        System.out.println("Message Number : " + msg.getMessageNumber());
        System.out.println("Message ID     : " + msg.getMessageID());
        System.out.println("Message Hash   : " + msg.getMessageHash());
        System.out.println("Sender         : " + msg.getSender());
        System.out.println("Recipient      : " + msg.getRecipient());
        System.out.println("Status         : " + msg.getStatus());
        System.out.println("Message        : " + msg.getMessageText());

        System.out.println("-----------------------------------");
    }
}
/*
 * Returns total stored messages.
 */
public int getStoredMessageCount() {

    return storedMessages.size();
}
/*
 * Returns total disregarded messages.
 */
public int getDisregardedMessageCount() {

    return disregardedMessages.size();
}


}
