
package prog5121poe;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class JsonManager {

    private static final String FILE_NAME = "storedMessages.json";

    /*
     * Save one message to the JSON file.
     */
    public static void saveMessage(Message message) {

        try {

            FileWriter fw = new FileWriter(FILE_NAME, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write("{");
            bw.newLine();

            bw.write("\"messageID\":\"" + message.getMessageID() + "\",");
            bw.newLine();

            bw.write("\"messageHash\":\"" + message.getMessageHash() + "\",");
            bw.newLine();

            bw.write("\"sender\":\"" + message.getSender() + "\",");
            bw.newLine();

            bw.write("\"recipient\":\"" + message.getRecipient() + "\",");
            bw.newLine();

            bw.write("\"status\":\"" + message.getStatus() + "\",");
            bw.newLine();

            bw.write("\"message\":\"" + message.getMessageText() + "\"");
            bw.newLine();

            bw.write("}");
            bw.newLine();

            bw.close();

        } catch (IOException e) {

            System.out.println("Error saving message.");
        }
    }

    /*
     * Display the contents of the JSON file.
     */
    public static void displayStoredMessagesFile() {

        try {

            File file = new File(FILE_NAME);

            if (!file.exists()) {

                System.out.println("No stored messages file found.");
                return;
            }

            BufferedReader br = new BufferedReader(new FileReader(file));

            String line;

            while ((line = br.readLine()) != null) {

                System.out.println(line);
            }

            br.close();

        } catch (IOException e) {

            System.out.println("Error reading stored messages.");
        }
    }

    /*
     * Returns all lines from the JSON file.
     */
    public static ArrayList<String> readFileLines() {

        ArrayList<String> lines = new ArrayList<String>();

        try {

            File file = new File(FILE_NAME);

            if (!file.exists()) {
                return lines;
            }

            BufferedReader br = new BufferedReader(new FileReader(file));

            String line;

            while ((line = br.readLine()) != null) {

                lines.add(line);
            }

            br.close();

        } catch (IOException e) {

            System.out.println("Error reading file.");
        }

        return lines;
    }

    /*
     * Clears the JSON file.
     */
    public static void clearFile() {

        try {

            FileWriter fw = new FileWriter(FILE_NAME);

            fw.write("");

            fw.close();

        } catch (IOException e) {

            System.out.println("Error clearing file.");
        }
    }

}
