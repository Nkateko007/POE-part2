package prog5121poe;

import java.util.Scanner;

/**
 * Main class for the QuickChat application.
 */
public class PROG5121POE {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Login login = new Login();

        System.out.println("=================================");
        System.out.println("      QUICKCHAT REGISTRATION");
        System.out.println("=================================");

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter Username: ");
        String username = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        System.out.print("Enter SA Cellphone (+27...): ");
        String phoneNumber = scanner.nextLine();

        // Username validation
        if (login.checkUserName(username)) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username incorrectly formatted.");
            return;
        }

        // Password validation
        if (login.checkPasswordComplexity(password)) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password incorrectly formatted.");
            return;
        }

        // Phone validation
        if (login.checkCellPhoneNumber(phoneNumber)) {
            System.out.println("Cellphone number successfully captured.");
        } else {
            System.out.println("Cellphone number incorrectly formatted.");
            return;
        }

        System.out.println();
        System.out.println("Registration successful.");

        System.out.println();
        System.out.println("============== LOGIN ==============");

        System.out.print("Username: ");
        String enteredUsername = scanner.nextLine();

        System.out.print("Password: ");
        String enteredPassword = scanner.nextLine();

        boolean loginSuccess = login.loginUser(
                username,
                password,
                enteredUsername,
                enteredPassword
        );

        System.out.println(
                login.returnLoginStatus(
                        loginSuccess,
                        firstName,
                        lastName
                )
        );

        if (!loginSuccess) {
            return;
        }

        System.out.println();
        System.out.println("Welcome to QuickChat.");

        MessageManager manager = new MessageManager();

        int choice;

        do {

            System.out.println();
            System.out.println("========== QUICKCHAT MENU ==========");
            System.out.println("1. Send Message");
            System.out.println("2. Store Message");
            System.out.println("3. Disregard Message");
            System.out.println("4. Display Sent Messages");
            System.out.println("5. Display Stored Messages");
            System.out.println("6. Display Longest Stored Message");
            System.out.println("7. Generate Report");
            System.out.println("8. Display JSON File");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");

            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {

                case 1:

                    System.out.print("Recipient Number: ");
                    String recipient1 = scanner.nextLine();

                    System.out.print("Message: ");
                    String text1 = scanner.nextLine();

                    Message sentMessage = new Message(
                            username,
                            recipient1,
                            text1,
                            manager.getTotalMessages() + 1,
                            "Sent"
                    );

                    manager.sendMessage(sentMessage);

                    System.out.println("Message sent.");
                    break;

                case 2:

                    System.out.print("Recipient Number: ");
                    String recipient2 = scanner.nextLine();

                    System.out.print("Message: ");
                    String text2 = scanner.nextLine();

                    Message storedMessage = new Message(
                            username,
                            recipient2,
                            text2,
                            manager.getTotalMessages() + 1,
                            "Stored"
                    );

                    manager.storeMessage(storedMessage);

                    System.out.println("Message stored.");
                    break;

                case 3:

                    System.out.print("Recipient Number: ");
                    String recipient3 = scanner.nextLine();

                    System.out.print("Message: ");
                    String text3 = scanner.nextLine();

                    Message disregardedMessage = new Message(
                            username,
                            recipient3,
                            text3,
                            manager.getTotalMessages() + 1,
                            "Disregarded"
                    );

                    manager.disregardMessage(disregardedMessage);

                    System.out.println("Message disregarded.");
                    break;

                case 4:

                    manager.displayAllSentMessages();
                    break;

                case 5:

                    manager.displayAllStoredMessages();
                    break;

                case 6:

                    manager.displayLongestStoredMessage();
                    break;

                case 7:

                    manager.generateReport();
                    break;

                case 8:

                    JsonManager.displayStoredMessagesFile();
                    break;

                case 9:

                    System.out.println("Exiting QuickChat...");
                    break;

                default:

                    System.out.println("Invalid option.");
            }

        } while (choice != 9);

        scanner.close();
    }
}